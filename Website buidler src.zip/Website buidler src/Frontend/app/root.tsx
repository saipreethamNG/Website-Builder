import {LinksFunction, LoaderFunction, MetaFunction} from "@remix-run/node"
import {Links, LiveReload, Meta, Outlet, Scripts, ScrollRestoration} from "@remix-run/react"
import FloatingLoader from "./components/transitions/FloatingLoader"
import styles from "./styles/app.css"
import {loadRootData, useRootData} from "./utils/useRootData"

export let links: LinksFunction = () => {
  return [{rel: "stylesheet", href: styles}]
}

export let loader: LoaderFunction = async ({request}) => {
  return loadRootData(request)
}

export const meta: MetaFunction = ({data}) => ({
  ...data?.metaTags,
})

function Document({children}: {children: React.ReactNode; title?: string}) {
  const rootData = useRootData()

  return (
    <html lang="en" className="h-full bg-white">
      <head>
        <Meta />
        <link rel="icon" type="image/png" sizes="192x192" href="/android-icon-192x192.png" />
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="96x96" href="/favicon-96x96.png" />
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />

        <Links />
      </head>

      <body className="h-full max-h-full min-h-screen max-w-full bg-white text-gray-800 dark:bg-slate-900 dark:text-white">
        {children}

        <LiveReload />
        <FloatingLoader />
        <ScrollRestoration />
        <Scripts />
      </body>
    </html>
  )
}

export default function App() {
  return (
    <Document>
      <Outlet />
    </Document>
  )
}
