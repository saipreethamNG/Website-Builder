import {LoaderArgs, MetaFunction, json} from "@remix-run/node"
import {useLoaderData} from "@remix-run/react"
import * as React from "react"
import invariant from "tiny-invariant"
import PageBlockEditMode from "~/components/PageBlockEditMode"
import PageBlocks from "~/components/PageBlocks"
import {requireUserId} from "~/lib/session.server"
import {getWebsiteById} from "~/lib/website.server"
import {PageBlockDto} from "~/types/PageBlockDto"

export type WebsiteBlocksLoaderData = {
  website: NonNullable<Awaited<ReturnType<typeof getWebsiteById>>>
  doesWebsiteBelongToCurrentUser: boolean
}
export const loader = async ({params, request}: LoaderArgs) => {
  const userId = await requireUserId(request)
  const {websiteId} = params

  invariant(websiteId, "websiteId is required")

  const website = await getWebsiteById(websiteId)

  if (!website) {
    throw json("Website not found", 404)
  }

  const doesWebsiteBelongToCurrentUser = website.userId === userId

  return json({
    website,
    doesWebsiteBelongToCurrentUser,
  })
}

export const meta: MetaFunction = ({data}) => ({
  title: `Website - ${data.website.name}`,
  description: data.website.description,
})

export default function WebsiteBlocks() {
  const {website, doesWebsiteBelongToCurrentUser} = useLoaderData<typeof loader>()
  const [blocks, setBlocks] = React.useState<PageBlockDto[]>(JSON.parse(website.blocks))

  return (
    <>
      <div>
        <PageBlockEditMode
          items={blocks}
          onSetBlocks={(e) => setBlocks(e)}
          isEditable={doesWebsiteBelongToCurrentUser}
        />
        <PageBlocks items={blocks} onChange={(e) => setBlocks(e)} isEditable={doesWebsiteBelongToCurrentUser} />
      </div>
    </>
  )
}
