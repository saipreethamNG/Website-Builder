import {ActionArgs, json, redirect} from "@remix-run/node"
import {updateWebsiteSettings} from "~/lib/website.server"

export const action = async ({request}: ActionArgs) => {
  const formData = await request.formData()
  const websiteId = formData.get("websiteId")?.toString()
  const name = formData.get("name")?.toString()
  const description = formData.get("description")?.toString()
  const privacy = formData.getAll("privacy")?.toString()

  if (!name || !description || !privacy || !websiteId) {
    return json("Please fill all the fields", 400)
  }

  await updateWebsiteSettings({
    websiteId,
    name,
    description,
  })

  return json({success: true})
}

export const loader = async () => {
  return redirect("/")
}
