import {Dialog, Transition} from "@headlessui/react"
import {GlobeAltIcon} from "@heroicons/react/24/outline"
import {ActionArgs, LoaderArgs, json, redirect} from "@remix-run/node"
import {Form, Link, useLoaderData} from "@remix-run/react"
import * as React from "react"
import {Fragment} from "react"
import ButtonPrimary from "~/components/ui/ButtonPrimary"
import ButtonTertiary from "~/components/ui/ButtonTertiary"
import {requireUserId} from "~/lib/session.server"
import {createWebsite, getWebsitesById} from "~/lib/website.server"

export const loader = async ({request}: LoaderArgs) => {
  const userId = await requireUserId(request)
  const websites = await getWebsitesById(userId)

  return json({websites})
}

export const action = async ({request}: ActionArgs) => {
  const userId = await requireUserId(request)
  const formData = await request.formData()

  const name = formData.get("name")?.toString()
  const description = formData.get("description")?.toString()

  if (!name || !description) {
    return json("Please fill all the fields", 400)
  }

  const website = await createWebsite({
    name,
    description,
    userId,
  })

  return redirect(`/websites/${website.id}?editMode=true`)
}

export default function Websites() {
  const {websites} = useLoaderData<typeof loader>()
  const [openAddWebsiteDrawer, setOpenAddWebsiteDrawer] = React.useState(false)

  return (
    <>
      <div className="mb-px border-b p-6 md:flex md:items-center md:justify-between">
        <div className="mt-4 flex w-full items-center justify-center">
          <ButtonPrimary type="button" onClick={() => setOpenAddWebsiteDrawer(true)}>
            Add Website
          </ButtonPrimary>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-4">
        {websites.length > 0 ? (
          websites.map((website) => {
            return (
              <div
                key={website.id}
                className="relative flex items-center space-x-3 rounded-lg border-2 border-gray-300 bg-white px-6 py-5 shadow-sm focus-within:ring-2 focus-within:ring-indigo-500 focus-within:ring-offset-2 hover:border-theme-400"
              >
                <div className="min-w-0 flex-1">
                  <Link to={website.id} className="focus:outline-none">
                    <span className="absolute inset-0" aria-hidden="true" />
                    <p className="flex items-center justify-between text-sm font-medium text-gray-900">
                      <span>{website.name}</span>
                    </p>
                    <p className="truncate text-sm text-gray-500">{website.description}</p>
                  </Link>
                </div>
              </div>
            )
          })
        ) : (
          <button
            onClick={() => setOpenAddWebsiteDrawer(true)}
            className="relative col-span-2 block w-full rounded-lg border border-dashed border-gray-300 bg-white p-12 text-center hover:bg-blue-50"
          >
            <GlobeAltIcon className="mx-auto h-10 w-10 text-gray-500" />
            <span className="mt-2 block text-sm text-gray-900">No websites have been added yet.</span>
            <span className="mt-6 block text-sm font-semibold text-gray-900">
              Click here to add your first website.
            </span>
          </button>
        )}
      </div>

      <Transition.Root show={openAddWebsiteDrawer} as={Fragment}>
        <Dialog as="div" className="relative z-10" onClose={setOpenAddWebsiteDrawer}>
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />

          <div className="fixed inset-0 overflow-hidden">
            <div className="absolute inset-0 overflow-hidden">
              <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10 sm:pl-16">
                <Dialog.Panel className="pointer-events-auto w-screen max-w-md">
                  <Form
                    method="POST"
                    replace
                    className="flex h-full flex-col divide-y divide-gray-200 bg-white shadow-xl"
                  >
                    <div className="h-0 flex-1 overflow-y-auto">
                      <div className="bg-white px-4 py-6 sm:px-6">
                        <div className="flex items-center justify-between">
                          <Dialog.Title className="text-base font-semibold leading-6 text-black">
                            New Website
                          </Dialog.Title>
                        </div>
                      </div>

                      <div className="flex flex-1 flex-col justify-between">
                        <div className="divide-y divide-gray-200 px-4 sm:px-6">
                          <div className="space-y-6 pb-5 pt-6">
                            <div>
                              <label htmlFor="name" className="block text-sm font-medium leading-6 text-gray-900">
                                Website name
                              </label>
                              <div className="mt-2">
                                <input
                                  type="text"
                                  name="name"
                                  id="name"
                                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                                />
                              </div>
                            </div>
                            <div>
                              <label
                                htmlFor="description"
                                className="block text-sm font-medium leading-6 text-gray-900"
                              >
                                Description
                              </label>
                              <div className="mt-2">
                                <textarea
                                  id="description"
                                  name="description"
                                  rows={4}
                                  className="block w-full rounded-md border-0 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:py-1.5 sm:text-sm sm:leading-6"
                                  defaultValue={""}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-shrink-0 justify-end gap-4 px-4 py-4">
                      <ButtonTertiary type="button" onClick={() => setOpenAddWebsiteDrawer(false)}>
                        Cancel
                      </ButtonTertiary>
                      <ButtonPrimary type="submit">Create website</ButtonPrimary>
                    </div>
                  </Form>
                </Dialog.Panel>
              </div>
            </div>
          </div>
        </Dialog>
      </Transition.Root>
    </>
  )
}
