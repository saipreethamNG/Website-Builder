import {ActionArgs, json, redirect} from "@remix-run/node"
import {requireUserId} from "~/lib/session.server"
import {updateWebsite} from "~/lib/website.server"

export const action = async ({request}: ActionArgs) => {
  const userId = await requireUserId(request)

  // Save the website
  const formData = await request.formData()
  const websiteId = formData.get("websiteId")?.toString()
  const blocks = formData.get("blocks")?.toString()

  if (!websiteId || !blocks) {
    throw new Error("Invalid data")
  }

  await updateWebsite({
    userId,
    websiteId,
    blocks,
  })

  return json({success: true})
}

export const loader = async () => {
  return redirect("/")
}
