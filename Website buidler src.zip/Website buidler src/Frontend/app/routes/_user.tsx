import {LoaderArgs} from "@remix-run/node"
import {Form, Outlet} from "@remix-run/react"
import {requireUserId} from "~/lib/session.server"
import {useUser} from "~/utils/utils"

export const loader = async ({request}: LoaderArgs) => {
  await requireUserId(request)
  return null
}

export default function UserLayoutRoute() {
  const user = useUser()

  return (
    <>
      <div className="flex h-full">
        <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
          <nav className="bg-gray-800">
            <div className="mx-auto max-w-7xl px-2 sm:px-6 lg:px-8">
              <div className="relative flex h-16 items-center justify-between">
                <div className="flex flex-1 items-center justify-between">
                  <div className="flex flex-shrink-0 items-center">
                    <span className="text-lg font-bold text-white">UCMO</span>
                  </div>
                  <div>
                    <span className="text-white">
                      <Form method="POST" action="/logout" replace className={"relative block h-full w-full "}>
                        <button className="w-full px-4 py-2 text-left text-sm font-bold uppercase">Sign out</button>
                      </Form>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </nav>

          <main className="relative z-0 flex-1 overflow-y-auto focus:outline-none xl:order-last">
            <div className="mx-auto max-w-7xl px-2 sm:px-6 lg:px-8">
              <Outlet />
            </div>
          </main>
        </div>
      </div>
    </>
  )
}
