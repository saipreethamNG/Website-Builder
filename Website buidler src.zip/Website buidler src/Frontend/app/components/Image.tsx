import {IImage} from "~/types/VideoBlockDto"

export default function Image({item}: {item: IImage}) {
  return (
    <>
      <div>
        <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <div className="space-y-8 sm:space-y-12">
            <div className="mx-auto my-12 mt-10 aspect-[16/9] max-w-2xl">
              <img src={item.src} alt={""} className="h-full w-full" />
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
