import * as React from "react"
import {useState} from "react"
import {FooterBlockDto} from "~/types/FooterBlockDto"
import {defaultFooter} from "~/utils/pages/defaultFooter"

export default function Footer({item}: {item: FooterBlockDto}) {
  const [footer, setFooter] = useState(item ?? defaultFooter())

  React.useEffect(() => {
    if (!footer) {
      setFooter(defaultFooter())
    } else {
      setFooter(item)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [item])

  return (
    <>
      {footer && (
        <>
          <footer className="body-font text-gray-600">
            <div className="container mx-auto flex flex-col flex-wrap px-5 py-24 md:flex-row md:flex-nowrap md:items-center lg:items-start">
              <div className="mx-auto w-64 flex-shrink-0 text-center md:mx-0 md:text-left">
                {item.text && <p className="mt-2 hidden text-sm text-gray-500 md:block">{item.text}</p>}
              </div>

              <ul className="-mb-10 mt-10 flex flex-grow flex-wrap text-center md:mt-0 md:pl-20 md:text-left">
                {item.sections.map((section, idx) => {
                  return (
                    <li key={idx} className="w-full px-4 md:w-1/2 lg:w-1/4">
                      <h2 className="title-font mb-3 text-sm font-medium tracking-widest text-gray-900 dark:text-white">
                        {section.name}
                      </h2>
                      <ul className="mb-10 list-none space-y-3">
                        {section.items.map((item, idx) => {
                          return (
                            <li key={idx}>
                              <span className="text-gray-600 hover:text-gray-800">
                                {footer.withBullets && `${idx + 1}. `}
                                {item.name}
                              </span>
                            </li>
                          )
                        })}
                      </ul>
                    </li>
                  )
                })}
              </ul>
            </div>
          </footer>
        </>
      )}
    </>
  )
}
