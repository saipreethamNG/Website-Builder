import {Dialog, Transition} from "@headlessui/react"
import {ArrowLeftIcon, XMarkIcon} from "@heroicons/react/20/solid"
import {useFetcher, useParams, useSearchParams} from "@remix-run/react"
import * as React from "react"
import ButtonPrimary from "~/components/ui/ButtonPrimary"
import ButtonSecondary from "~/components/ui/ButtonSecondary"
import OpenModal from "~/components/ui/OpenModal"
import {PageBlockDto} from "~/types/PageBlockDto"
import {useWebsiteData} from "~/utils/utils"

type MessageDto = {
  success?: {title: string; message: string}
  error?: {title: string; message: string}
}

export default function PageBlockEditMode({
  items,
  onSetBlocks,
  isEditable,
}: {
  items: PageBlockDto[]
  onSetBlocks: (items: PageBlockDto[]) => void
  isEditable: boolean
}) {
  const saveWebsiteFetcher = useFetcher<{
    success: string
  }>()
  const updateWebsiteSettingsFetcher = useFetcher<{
    success: string
  }>()

  const {website} = useWebsiteData()

  const [searchParams, setSearchParams] = useSearchParams()
  const {websiteId} = useParams()
  const [message, setMessage] = React.useState<MessageDto>()
  const [editWebsiteSetting, setEditWebsiteSetting] = React.useState(false)

  const isEditMode = isEditable ? searchParams.get("editMode") !== "false" : false
  const onReset = () => onSetBlocks([])

  function toggleEditMode() {
    if (searchParams.get("editMode") === "false") {
      setSearchParams({editMode: "true"})
    } else {
      setSearchParams({editMode: "false"})
    }
  }

  function onSave() {
    saveWebsiteFetcher.submit(
      {
        blocks: JSON.stringify(items),
        websiteId: websiteId || "",
      },
      {
        action: "/api/website/save",
        method: "POST",
        replace: true,
      }
    )
  }

  React.useEffect(() => {
    if (saveWebsiteFetcher.state !== "idle") return

    if (saveWebsiteFetcher.data) {
      setMessage({
        success: {
          title: "Website saved",
          message:
            "Your website have been saved. You can now exit edit mode and view your website. If you want to edit your blocks again, click the edit button on the top-center of the page.",
        },
      })

      toggleEditMode()
    }
  }, [saveWebsiteFetcher.state, saveWebsiteFetcher.data])

  React.useEffect(() => {
    if (updateWebsiteSettingsFetcher.state !== "idle") return

    if (updateWebsiteSettingsFetcher.data) {
      setMessage({
        success: {
          title: "Website saved",
          message: "Your website have been saved.",
        },
      })

      setEditWebsiteSetting(false)
    }
  }, [updateWebsiteSettingsFetcher.state, updateWebsiteSettingsFetcher.data])

  return (
    <div>
      {isEditMode ? (
        <div className="bg-gray-900 p-2 text-gray-50 dark:bg-gray-50 dark:text-gray-900">
          <div className="flex justify-between gap-3">
            <ButtonSecondary to="/websites" className="w-max">
              <div className="flex items-center gap-3">
                <ArrowLeftIcon className="h-5 w-5" />
                <span>back</span>
              </div>
            </ButtonSecondary>
            <div className="flex items-center gap-3">
              <ButtonSecondary onClick={onSave}>
                <div>
                  <span className="hidden sm:block">Save Website</span>
                  <span className="sm:hidden">Save</span>
                </div>
              </ButtonSecondary>
              <ButtonSecondary onClick={onReset}>
                <div>
                  <span className="hidden sm:block">Reset</span>
                  <span className="sm:hidden">Rest</span>
                </div>
              </ButtonSecondary>
              <ButtonPrimary onClick={toggleEditMode}>
                <div>
                  <span className="hidden sm:block">Exit Edit Mode</span>
                  <span className="sm:hidden">Exit</span>
                </div>
              </ButtonPrimary>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-gray-900 p-2 text-gray-50 dark:bg-gray-50 dark:text-gray-900">
          <div className="flex justify-between space-x-3">
            <ButtonSecondary to="/websites">
              <div>
                <span className="hidden sm:block">View all websites</span>
                <span className="sm:hidden">Websites</span>
              </div>
            </ButtonSecondary>
            {isEditable && (
              <div className="space-x-3">
                <ButtonSecondary onClick={toggleEditMode}>
                  <div>
                    <span className="hidden sm:block">Edit Website</span>
                    <span className="sm:hidden">Edit</span>
                  </div>
                </ButtonSecondary>
              </div>
            )}
          </div>
        </div>
      )}

      <OpenModal type="success" {...message?.success} open={!!message?.success} onClose={() => setMessage(undefined)} />
      <OpenModal type="error" {...message?.error} open={!!message?.error} onClose={() => setMessage(undefined)} />

      <Transition.Root show={editWebsiteSetting} as={React.Fragment}>
        <Dialog as="div" className="relative z-10" onClose={setEditWebsiteSetting}>
          <Transition.Child
            as={React.Fragment}
            enter="ease-in-out duration-500"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in-out duration-500"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
          </Transition.Child>

          <div className="fixed inset-0 overflow-hidden">
            <div className="absolute inset-0 overflow-hidden">
              <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10 sm:pl-16">
                <Transition.Child
                  as={React.Fragment}
                  enter="transform transition ease-in-out duration-500 sm:duration-700"
                  enterFrom="translate-x-full"
                  enterTo="translate-x-0"
                  leave="transform transition ease-in-out duration-500 sm:duration-700"
                  leaveFrom="translate-x-0"
                  leaveTo="translate-x-full"
                >
                  <Dialog.Panel className="pointer-events-auto w-screen max-w-md">
                    <updateWebsiteSettingsFetcher.Form
                      method="POST"
                      replace
                      action="/api/website/update-settings"
                      className="flex h-full flex-col divide-y divide-gray-200 bg-white shadow-xl"
                    >
                      <input hidden defaultValue={website.id} name="websiteId" />
                      <div className="h-0 flex-1 overflow-y-auto">
                        <div className="bg-indigo-700 px-4 py-6 sm:px-6">
                          <div className="flex items-center justify-between">
                            <Dialog.Title className="text-base font-semibold leading-6 text-white">
                              Edit Website
                            </Dialog.Title>

                            <div className="ml-3 flex h-7 items-center">
                              <button
                                type="button"
                                className="rounded-md bg-indigo-700 text-indigo-200 hover:text-white focus:outline-none focus:ring-2 focus:ring-white"
                                onClick={() => setEditWebsiteSetting(false)}
                              >
                                <span className="sr-only">Close panel</span>
                                <XMarkIcon className="h-6 w-6" aria-hidden="true" />
                              </button>
                            </div>
                          </div>
                          <div className="mt-1">
                            <p className="text-sm text-indigo-300">Edit your website settings.</p>
                          </div>
                        </div>

                        <div className="flex flex-1 flex-col justify-between">
                          <div className="divide-y divide-gray-200 px-4 sm:px-6">
                            <div className="space-y-6 pb-5 pt-6">
                              <div>
                                <label htmlFor="name" className="block text-sm font-medium leading-6 text-gray-900">
                                  Website name
                                </label>
                                <div className="mt-2">
                                  <input
                                    type="text"
                                    name="name"
                                    id="name"
                                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                                    defaultValue={website.name}
                                  />
                                </div>
                              </div>
                              <div>
                                <label
                                  htmlFor="description"
                                  className="block text-sm font-medium leading-6 text-gray-900"
                                >
                                  Description
                                </label>
                                <div className="mt-2">
                                  <textarea
                                    id="description"
                                    name="description"
                                    rows={4}
                                    className="block w-full rounded-md border-0 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:py-1.5 sm:text-sm sm:leading-6"
                                    defaultValue={website.description}
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-shrink-0 justify-end px-4 py-4">
                        <button
                          type="button"
                          className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50"
                          onClick={() => setEditWebsiteSetting(false)}
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="ml-4 inline-flex justify-center rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                        >
                          Update website
                        </button>
                      </div>
                    </updateWebsiteSettingsFetcher.Form>
                  </Dialog.Panel>
                </Transition.Child>
              </div>
            </div>
          </div>
        </Dialog>
      </Transition.Root>
    </div>
  )
}
