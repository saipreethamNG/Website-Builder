import ButtonSecondary from "~/components/ui/ButtonSecondary"
import {PageBlockDto} from "~/types/PageBlockDto"
import FaqBlockForm from "./FaqBlockForm"
import FooterBlockForm from "./FooterBlockForm"
import HeroBlockForm from "./HeroBlockForm"
import ImageBlockForm from "./ImageBlockForm"

interface Props {
  type: string
  item?: PageBlockDto
  onUpdate: (item: PageBlockDto) => void
  onClose: () => void
}
export default function PageBlockForm({type, item, onUpdate, onClose}: Props) {
  const block = Block({type, item, onUpdate, onClose})

  return (
    <div>
      {block}
      <div className="mt-2 flex justify-end">
        <ButtonSecondary onClick={onClose}>Close</ButtonSecondary>
      </div>
    </div>
  )
}

function Block({type, item, onUpdate}: Props) {
  if (type === "footer") {
    return <FooterBlockForm item={item?.footer} onUpdate={(footer) => onUpdate({footer})} />
  } else if (type === "hero") {
    return <HeroBlockForm item={item?.hero} onUpdate={(hero) => onUpdate({hero})} />
  } else if (type === "image") {
    return <ImageBlockForm item={item?.image} onUpdate={(image) => onUpdate({image})} />
  } else if (type === "faq") {
    return <FaqBlockForm item={item?.faq} onUpdate={(faq) => onUpdate({faq})} />
  } else {
    return <div>TODO</div>
  }
}
