import {HeroBlockDto} from "~/types/HeroBlockDto"

export default function Hero({item}: {item: HeroBlockDto}) {
  return (
    <>
      <section>
        <div className="mx-auto max-w-screen-xl px-4 py-16 lg:flex lg:items-center">
          <div className="mx-auto max-w-7xl text-center md:max-w-6xl">
            <h1
              className="flex flex-col text-4xl font-extrabold sm:text-5xl md:text-5xl lg:text-7xl"
              style={{
                fontWeight: item.style?.bold ? "bold" : "normal",
                textDecoration: item.style?.underline ? "underline" : "",
                color: item.style?.color ?? "black",
                fontSize: item.style?.fontSize ? `${item.style?.fontSize}px` : "16px",
              }}
            >
              {item.headline}
            </h1>
          </div>
        </div>
      </section>
    </>
  )
}
