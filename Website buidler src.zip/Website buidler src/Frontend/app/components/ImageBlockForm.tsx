import {useEffect, useState} from "react"
import InputGroup from "~/components/ui/InputGroup"
import InputText from "~/components/ui/InputText"
import {IImage} from "~/types/VideoBlockDto"
import PageBlockUtils from "~/utils/PageBlockUtils"

export default function ImageBlockForm({item, onUpdate}: {item?: IImage; onUpdate: (item: IImage) => void}) {
  const [state, setState] = useState<IImage>(item || PageBlockUtils.defaultBlocks.image!)
  useEffect(() => {
    onUpdate(state)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state])
  return (
    <div className="space-y-4">
      <InputGroup title="Image">
        <div className="space-y-2">
          <InputText
            title="Source"
            type="text"
            value={state.src}
            setValue={(e) => setState({...state, src: e.toString()})}
          />
        </div>
      </InputGroup>
    </div>
  )
}
