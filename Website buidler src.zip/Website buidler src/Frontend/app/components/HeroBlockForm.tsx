import {useEffect, useState} from "react"
import InputCheckbox from "~/components/ui/InputCheckbox"
import InputGroup from "~/components/ui/InputGroup"
import InputNumber from "~/components/ui/InputNumber"
import InputSelector from "~/components/ui/InputSelector"
import InputText from "~/components/ui/InputText"
import {HeroBlockDto} from "~/types/HeroBlockDto"
import PageBlockUtils from "~/utils/PageBlockUtils"

export default function HeroBlockForm({item, onUpdate}: {item?: HeroBlockDto; onUpdate: (item: HeroBlockDto) => void}) {
  const [state, setState] = useState<HeroBlockDto>(item || PageBlockUtils.defaultBlocks.hero!)

  useEffect(() => {
    onUpdate(state)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state])
  return (
    <div className="space-y-4">
      <InputGroup title="Hero">
        <div className="space-y-2">
          <InputText
            title="Headline"
            type="text"
            value={state.headline}
            setValue={(e) => setState({...state, headline: e.toString()})}
          />

          <div className="grid grid-cols-2 gap-2">
            <InputSelector
              title="Color"
              selectPlaceholder="Select color"
              options={[
                {
                  name: "Red",
                  value: "red",
                },
                {
                  name: "Blue",
                  value: "blue",
                },
                {
                  name: "Green",
                  value: "green",
                },
                {
                  name: "Black",
                  value: "black",
                },
                {
                  name: "Yellow",
                  value: "yellow",
                },
                {
                  name: "Purple",
                  value: "purple",
                },
                {
                  name: "Orange",
                  value: "orange",
                },
                {
                  name: "Pink",
                  value: "pink",
                },
                {
                  name: "Brown",
                  value: "brown",
                },
                {
                  name: "Gray",
                  value: "gray",
                },
              ]}
              value={state.style?.color}
              setValue={(e) => {
                setState({
                  ...state,
                  style: {...state.style, color: String(e)},
                })
              }}
            />
            <InputNumber
              title="Font Size (px)"
              value={state.style?.fontSize}
              setValue={(e) => {
                setState({
                  ...state,
                  style: {...state.style, fontSize: Number(e)},
                })
              }}
            />

            <InputCheckbox
              title="Is bold"
              value={state.style?.bold}
              setValue={(e) =>
                setState({
                  ...state,
                  style: {...state.style, bold: Boolean(e)},
                })
              }
            />
            <InputCheckbox
              title="Is underline"
              value={state.style?.underline}
              setValue={(e) =>
                setState({
                  ...state,
                  style: {...state.style, underline: Boolean(e)},
                })
              }
            />
          </div>
        </div>
      </InputGroup>
    </div>
  )
}
