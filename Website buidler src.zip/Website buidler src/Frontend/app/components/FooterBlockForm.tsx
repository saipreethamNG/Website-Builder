import {useEffect, useState} from "react"
import ButtonTertiary from "~/components/ui/ButtonTertiary"
import CollapsibleRow from "~/components/ui/CollapsibleRow"
import InputCheckbox from "~/components/ui/InputCheckbox"
import InputGroup from "~/components/ui/InputGroup"
import InputText from "~/components/ui/InputText"
import {FooterBlockDto} from "~/types/FooterBlockDto"
import PageBlockUtils from "~/utils/PageBlockUtils"

export default function FooterBlockForm({
  item,
  onUpdate,
}: {
  item?: FooterBlockDto
  onUpdate: (item: FooterBlockDto) => void
}) {
  const [state, setState] = useState<FooterBlockDto>(item || PageBlockUtils.defaultBlocks.footer!)

  useEffect(() => {
    onUpdate(state)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state])
  return (
    <div className="space-y-4">
      <InputGroup title="Footer">
        <InputText
          title="Text"
          value={state.text}
          setValue={(value) => setState({...state, text: value?.toString()})}
        />
        <InputCheckbox
          title="With bullets"
          value={state.withBullets}
          setValue={(value) => setState({...state, withBullets: Boolean(value)})}
        />
      </InputGroup>

      <InputGroup title="Links">
        <div className="flex flex-col space-y-2">
          {state.sections.map((item, idx) => (
            <SectionForm
              key={idx}
              item={item}
              onUpdate={(item) => setState({...state, sections: state.sections?.map((x, i) => (i === idx ? item : x))})}
              onRemove={() => setState({...state, sections: state.sections?.filter((x, i) => i !== idx)})}
            />
          ))}
          <ButtonTertiary
            onClick={() =>
              setState({
                ...state,
                sections: [
                  ...state.sections,
                  {
                    name: "Section " + (state.sections.length + 1),
                    items: [],
                  },
                ],
              })
            }
          >
            Add section
          </ButtonTertiary>
        </div>
      </InputGroup>
    </div>
  )
}

function SectionForm({
  item,
  onRemove,
  onUpdate,
}: {
  item: FooterBlockDto["sections"][0]
  onRemove: () => void
  onUpdate: (item: FooterBlockDto["sections"][0]) => void
  isSublink?: boolean
}) {
  const [state, setState] = useState<FooterBlockDto["sections"][0]>(item)
  useEffect(() => {
    onUpdate(state)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state])

  return (
    <CollapsibleRow
      title={item.name}
      value={item.name}
      initial={!item.items || item.items.length === 0}
      onRemove={onRemove}
    >
      <div className="space-y-2">
        <InputText
          name="title"
          title="Name"
          value={item.name}
          setValue={(e) => setState({...state, name: e.toString()})}
          placeholder="Section name"
        />
      </div>
    </CollapsibleRow>
  )
}
