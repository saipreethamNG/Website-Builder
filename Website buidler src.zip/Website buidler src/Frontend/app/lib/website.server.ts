import {User, Website} from "@prisma/client"
import {db} from "~/lib/prisma.server"

function createWebsite({
  name,
  description,
  userId,
}: {
  name: Website["name"]
  description: Website["description"]
  userId: User["id"]
}) {
  return db.website.create({
    data: {
      name,
      description,
      userId,
      blocks: "[]",
    },
  })
}

function getWebsitesById(userId: User["id"]) {
  return db.website.findMany({
    orderBy: {
      updatedAt: "desc",
    },
    where: {
      userId,
    },
  })
}

function getWebsiteById(websiteId: Website["id"]) {
  return db.website.findFirst({
    where: {
      id: websiteId,
    },
    select: {
      id: true,
      name: true,
      description: true,
      blocks: true,
      userId: true,
    },
  })
}

function updateWebsite({
  userId,
  websiteId,
  blocks,
}: {
  userId: User["id"]
  websiteId: Website["id"]
  blocks: Website["blocks"]
}) {
  return db.website.update({
    where: {
      id: websiteId,
      userId,
    },
    data: {
      blocks,
    },
  })
}

function updateWebsiteSettings({
  websiteId,
  name,
  description,
}: {
  name: Website["name"]
  websiteId: Website["id"]
  description: Website["description"]
}) {
  return db.website.update({
    where: {
      id: websiteId,
    },
    data: {
      name,
      description,
    },
  })
}

export {createWebsite, getWebsiteById, getWebsitesById, updateWebsite, updateWebsiteSettings}
