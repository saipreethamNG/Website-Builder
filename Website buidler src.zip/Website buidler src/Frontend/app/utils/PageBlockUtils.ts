import {PageBlockDto} from "~/types/PageBlockDto"

const types = ["hero", "image", "faq", "footer"]

function getType(item: PageBlockDto) {
  if (item.footer) {
    return "footer"
  } else if (item.hero) {
    return "hero"
  } else if (item.image) {
    return "image"
  } else if (item.faq) {
    return "faq"
  }
  return ""
}

function getTypeTitle(type: string) {
  switch (type) {
    case "footer":
      return "List (Example)"
    case "hero":
      return "Text (Example)"
    case "image":
      return "Image (Example)"
    case "faq":
      return "Table (Example)s"
    default:
      return ""
  }
}

function downloadBlocks(blocks: PageBlockDto[]) {
  try {
    return JSON.stringify(blocks, null, "\t")
  } catch (e: any) {
    // eslint-disable-next-line no-console
    console.log(e.message)
    return "{}"
  }
}

const defaultBlocks: PageBlockDto = {
  footer: {
    text: "List example",
    withBullets: true,
    sections: [
      {
        name: "Application",
        items: [{name: "Contact"}, {name: "Newsletter"}],
      },
      {
        name: "Product",
        items: [{name: "Terms and Conditions"}, {name: "Privacy Policy"}],
      },
    ],
  },
  hero: {
    headline: "Landing Page Text",
    style: {
      underline: false,
      bold: true,
      color: "black",
      fontSize: 48,
    },
  },
  image: {
    src: "https://images.unsplash.com/photo-1682271315883-391288bc79fa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80",
  },
  faq: {
    items: [
      {
        question: "Question 1?",
        answer:
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ",
      },
      {
        question: "Question 2?",
        answer:
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ",
      },
      {
        question: "Question 3?",
        answer:
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ",
      },
      {
        question: "Question 4 with link?",
        answer:
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ",
      },
    ],
  },
}

export default {
  getType,
  getTypeTitle,
  types,
  defaultBlocks,
  downloadBlocks,
}
