import {BannerBlockStyle} from "~/types/BannerBlockDto"
import {CommunityBlockStyle} from "~/types/CommunityBlockDto"
import {FaqBlockStyle} from "~/types/FaqBlockDto"
import {FeaturesBlockStyle} from "~/types/FeaturesBlockDto"
import {FooterBlockStyle} from "~/types/FooterBlockDto"
import {GalleryBlockStyle} from "~/types/GalleryBlockDto"
import {HeaderBlockStyle} from "~/types/HeaderBlockDto"
import {HeroBlockStyle} from "~/types/HeroBlockDto"
import {LogoCloudsBlockStyle} from "~/types/LogoCloudsBlockDto"
import {NewsletterBlockStyle} from "~/types/NewsletterBlockDto"
import {PageBlockDto} from "~/types/PageBlockDto"
import {TestimonialsBlockStyle} from "~/types/TestimonialsBlockDto"
import {VideoBlockStyle} from "~/types/VideoBlockDto"

const defaultStyles = {
  banner: BannerBlockStyle.top,
  header: HeaderBlockStyle.simple,
  footer: FooterBlockStyle.columns,
  hero: HeroBlockStyle.simple,
  gallery: GalleryBlockStyle.carousel,
  logoClouds: LogoCloudsBlockStyle.simple,
  video: VideoBlockStyle.simple,
  community: CommunityBlockStyle.simple,
  testimonials: TestimonialsBlockStyle.simple,
  features: FeaturesBlockStyle.list,
  newsletter: NewsletterBlockStyle.rightForm,
  faq: FaqBlockStyle.simple,
}

export function CustomTemplate() {
  const blocks: PageBlockDto[] = [
    // Hero
    {
      hero: {
        style: defaultStyles.hero,
        headline: "Put your template here",
        subheadline:
          "Edit /utils/services/pages/templates/CustomTemplate.ts to customize this template. You can also use the Page Builder to create your own pages.",
        cta: [],
      },
    },
  ]
  return blocks
}
