export function iconBackgroundRandomizer() {
  const actions = [
    {
      iconForeground: "text-teal-700",
      iconBackground: "bg-teal-50",
    },
    {
      iconForeground: "text-purple-700",
      iconBackground: "bg-purple-50",
    },
    {
      iconForeground: "text-sky-700",
      iconBackground: "bg-sky-50",
    },
    {
      iconForeground: "text-yellow-700",
      iconBackground: "bg-yellow-50",
    },
    {
      iconForeground: "text-rose-700",
      iconBackground: "bg-rose-50",
    },
    {
      iconForeground: "text-indigo-700",
      iconBackground: "bg-indigo-50",
    },
  ]

  const randomIndex = Math.floor(Math.random() * actions.length)
  return {
    iconForeground: actions[randomIndex].iconForeground,
    iconBackground: actions[randomIndex].iconBackground,
  }
}

export function formatDateTime(date: string) {
  const formatter = new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  })

  return formatter.format(new Date(date))
}
