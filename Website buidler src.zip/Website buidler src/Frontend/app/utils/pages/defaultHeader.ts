import {HeaderBlockDto, HeaderBlockStyle} from "~/types/HeaderBlockDto"

export function defaultHeader(): HeaderBlockDto {
  return {
    style: HeaderBlockStyle.simple,
    withLogo: true,
    withSignInAndSignUp: false,
    links: [
      {path: "/", title: "Home"},
      {path: "/contact", title: "Contact"},
      {path: "/newsletter", title: "Newsletter"},
    ],
  }
}
