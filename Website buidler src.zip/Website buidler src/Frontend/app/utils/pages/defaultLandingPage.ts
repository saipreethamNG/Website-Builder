import {BannerBlockStyle} from "~/types/BannerBlockDto"
import {CommunityBlockStyle} from "~/types/CommunityBlockDto"
import {FaqBlockStyle} from "~/types/FaqBlockDto"
import {FeaturesBlockStyle} from "~/types/FeaturesBlockDto"
import {FooterBlockStyle} from "~/types/FooterBlockDto"
import {GalleryBlockStyle} from "~/types/GalleryBlockDto"
import {HeaderBlockStyle} from "~/types/HeaderBlockDto"
import {HeroBlockStyle} from "~/types/HeroBlockDto"
import {LogoCloudsBlockStyle} from "~/types/LogoCloudsBlockDto"
import {NewsletterBlockStyle} from "~/types/NewsletterBlockDto"
import {PageBlockDto} from "~/types/PageBlockDto"
import {TestimonialsBlockStyle} from "~/types/TestimonialsBlockDto"
import {VideoBlockStyle} from "~/types/VideoBlockDto"
import {defaultHeader} from "./defaultHeader"
import {defaultFooter} from "~/utils/pages/defaultFooter"

const defaultStyles = {
  banner: BannerBlockStyle.top,
  header: HeaderBlockStyle.simple,
  footer: FooterBlockStyle.columns,
  hero: HeroBlockStyle.simple,
  gallery: GalleryBlockStyle.carousel,
  logoClouds: LogoCloudsBlockStyle.simple,
  video: VideoBlockStyle.simple,
  community: CommunityBlockStyle.simple,
  testimonials: TestimonialsBlockStyle.simple,
  features: FeaturesBlockStyle.list,
  newsletter: NewsletterBlockStyle.rightForm,
  faq: FaqBlockStyle.simple,
}

export function defaultLandingPage() {
  const blocks: PageBlockDto[] = [
    // Banner
    {
      banner: {
        style: defaultStyles.banner,
        text: "Welcome to React Page Builder!.",
        cta: [{text: "Learn more", href: "https://www.ucmo.edu"}],
      },
    },
    // Header
    {
      header: defaultHeader(),
    },
    // Hero
    {
      hero: {
        style: defaultStyles.hero,
        headline: "React Page Builder",
        subheadline: "A collection of functional blocks",
        image: "https://via.placeholder.com/720x600?text=Your%20Hero%20Image",
        cta: [
          {
            text: "Built by SaasRock",
            href: "https://saasrock.com/?ref=remix-page-blocks-hero",
            isPrimary: false,
            target: "_blank",
          },
        ],
        topText: {
          text: "UCMO",
        },
      },
    },
    // Logo Clouds
    {
      logoClouds: {
        style: defaultStyles.logoClouds,
        headline: "First-class tech stack",
        logos: [
          {
            alt: "Remix",
            href: "https://www.ucmo.edu",
            src: "https://saasrock.com/build/_assets/remix-4ESNCVZ5.png",
            srcDark: "https://saasrock.com/build/_assets/remix-dark-U2ASPSOI.png",
          },
          {
            alt: "Tailwind CSS",
            href: "https://www.ucmo.edu",
            src: "https://saasrock.com/build/_assets/tailwindcss-G3OQBAVI.png",
          },
          {
            alt: "Prisma",
            href: "https://www.ucmo.edu",
            src: "https://saasrock.com/build/_assets/prisma-ATY77GXX.png",
            srcDark: "https://saasrock.com/build/_assets/prisma-dark-3FBYDJ4J.png",
          },
        ],
      },
    },
    // Gallery
    {
      gallery: {
        style: defaultStyles.gallery,
        topText: "Gallery",
        headline: "Headline Gallery",
        subheadline: "A collection of functional blocks",
        images: [
          {
            title: "Image 01",
            src: "https://via.placeholder.com/2560x1392",
          },
          {
            title: "Image 02",
            src: "https://via.placeholder.com/2560x1392",
          },
          {
            title: "Image 03",
            src: "https://via.placeholder.com/2560x1392",
          },
        ],
      },
    },
    // Video #1
    {
      video: {
        style: defaultStyles.video,
        headline: "Video Section",
        subheadline: "Embed your videos from Youtube, Vimeo, or Loom.",
        src: "https://www.youtube.com/embed/prf7HbDwsD0",
      },
    },
    // Community
    {
      community: {
        style: defaultStyles.community,
        headline: "Our Team",
        subheadline: "Meet the team behind React Page Builder",
        type: "manual",
        members: [
          {user: "Michael Jackson", avatar_url: "https://via.placeholder.com/60x60?text=S"},
          {user: "Alexandro Martinez", avatar_url: "https://via.placeholder.com/60x60?text=S"},
          {user: "Ryan Florence", avatar_url: "https://via.placeholder.com/60x60?text=S"},
        ],
        cta: [],
      },
    },
    // Testimonials
    {
      testimonials: {
        style: defaultStyles.testimonials,
        headline: "Don't take our word for it.",
        subheadline: ``,
        items: [
          {
            role: "Developer",
            company: "UCMO",
            companyUrl: "https://saasrock.com/?ref=remix-page-blocks-testimonials",
            logoLightMode: "https://saasrock.com/build/_assets/logo-light-STK7BWWF.png",
            logoDarkMode: "https://saasrock.com/build/_assets/logo-dark-DBF6MLNQ.png",
            name: "Alexandro Martínez",
            personalWebsite: "https://www.ucmo.edu",
            avatar: "https://via.placeholder.com/60x60?text=S",
            quote: "I love React Page Builder! It's so easy to use and customize.",
          },
          {
            role: "CEO",
            company: "Piloterr",
            companyUrl: "https://www.piloterr.com/?ref=remix-page-blocks",
            logoLightMode: "https://yahooder.sirv.com/saasrock/testimonials/piloterr-light.png",
            logoDarkMode: "https://yahooder.sirv.com/saasrock/testimonials/piloterr-dark.png",
            name: "Josselin Liebe",
            personalWebsite: "https://www.ucmo.edu",
            avatar: "https://via.placeholder.com/60x60?text=S",
            quote: "You've already solved 90% of my problems with your project :)",
          },
        ],
      },
    },
    // Features #1
    {
      features: {
        style: FeaturesBlockStyle.cards,
        topText: "Features",
        headline: "Features Section",
        subheadline: "List your features with icons and descriptions.",
        columns: 3,
        items: [
          {name: "L1", description: "L1 Description"},
          {name: "L2", description: "L2 Description"},
          {name: "L3", description: "L3 Description"},
          {name: "L4", description: "L4 Description"},
          {name: "L5", description: "L5 Description"},
          {name: "L6", description: "L6 Description"},
        ],
      },
    },
    // Newsletter
    {
      newsletter: {
        style: defaultStyles.newsletter,
        headline: "Subscribe to our newsletter to get the latest updates",
        subheadline: "Subscribe to our newsletter to get the latest updates and news.",
      },
    },
    // Faq
    {
      faq: {
        style: defaultStyles.faq,
        headline: "Frequently Asked Questions",
        subheadline: "List your frequently asked questions.",
        items: [
          {
            question: "Question 1?",
            answer:
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
          },
          {
            question: "Question 2?",
            answer:
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
          },
          {
            question: "Question 3?",
            answer:
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
          },
          {
            question: "Question 4?",
            answer:
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
          },
          {
            question: "Question 5?",
            answer:
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
          },
          {
            question: "Question 6 with link?",
            answer:
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            link: {
              text: "Visit my other boilerplates",
              href: "https://alexandromg.gumroad.com/?ref=remix-page-blocks-faq",
              target: "_blank",
            },
          },
        ],
      },
    },
    // Footer
    {
      footer: defaultFooter(),
    },
  ]
  return blocks
}
