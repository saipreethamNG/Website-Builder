import {FooterBlockDto} from "~/types/FooterBlockDto"

export function defaultFooter(): FooterBlockDto {
  return {
    text: `©${new Date().getFullYear()} UCMO`,
    sections: [
      {
        name: "UCMO",
        items: [{name: "Item 01"}, {name: "Item 02"}, {name: "Item 03"}],
      },
    ],
  }
}
