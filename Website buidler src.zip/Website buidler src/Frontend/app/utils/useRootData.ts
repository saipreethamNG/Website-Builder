import {json} from "@remix-run/node"
import {useRouteLoaderData} from "@remix-run/react"
import {MetaTagsDto} from "~/types/MetaTagsDto"
import {getSeoMetaTags} from "./services/seoService"
import {User} from "@prisma/client"
import {getUser} from "~/lib/session.server"

export type AppRootData = {
  title: string
  metaTags: MetaTagsDto
  user: User | null
  debug: boolean
}

export function useRootData(): AppRootData {
  return useRouteLoaderData("root") as AppRootData
}

export async function loadRootData(request: Request) {
  const user = await getUser(request)

  const data: AppRootData = {
    title: `${process.env.APP_NAME}`,
    user,
    debug: process.env.NODE_ENV === "development",
    metaTags: await getSeoMetaTags(),
  }

  return json(data)
}
