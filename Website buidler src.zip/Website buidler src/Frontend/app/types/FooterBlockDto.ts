export interface FooterBlockDto {
  text?: string
  withBullets: boolean
  sections: {
    name: string
    items: {name: string}[]
  }[]
}
