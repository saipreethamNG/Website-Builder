export interface FaqBlockDto {
  headline?: string
  subheadline?: string
  items: {
    question: string
    answer: string
  }[]
}
