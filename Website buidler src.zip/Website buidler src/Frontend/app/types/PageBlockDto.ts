import {FaqBlockDto} from "./FaqBlockDto"
import {FooterBlockDto} from "./FooterBlockDto"
import {HeroBlockDto} from "./HeroBlockDto"
import {IImage} from "./VideoBlockDto"

export type PageBlockDto = {
  footer?: FooterBlockDto
  hero?: HeroBlockDto
  image?: IImage
  faq?: FaqBlockDto
}
