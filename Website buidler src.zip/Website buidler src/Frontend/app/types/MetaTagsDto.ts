export type MetaTagsDto = {
  [name: string]: string
}
