export interface TestimonialDto {
  company: string
  companyUrl: string
  logoLightMode?: string
  logoDarkMode?: string
  quote: string
  name: string
  personalWebsite?: string
  avatar: string
  role: string
}
