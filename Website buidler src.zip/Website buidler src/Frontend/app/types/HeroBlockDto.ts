export interface HeroBlockDto {
  headline: string
  style: {
    underline: boolean
    bold: boolean
    color: string
    fontSize: number
  }
}
