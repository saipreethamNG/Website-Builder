export interface SocialsDto {
  instagram?: string
  twitter?: string
  github?: string
  discord?: string
}
