export interface TopBannerBlockDto {
  text: string
  cta: {
    text: string
    href: string
  }[]
}
