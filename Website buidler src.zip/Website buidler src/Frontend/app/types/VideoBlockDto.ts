export interface IImage {
  src: string
}
