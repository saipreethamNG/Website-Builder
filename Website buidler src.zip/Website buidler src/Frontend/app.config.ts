import {HomeIcon} from "@heroicons/react/24/outline"

const appConfig = {
  navigation: [{name: "Websites", href: "/websites", icon: HomeIcon}],
}

export default appConfig
