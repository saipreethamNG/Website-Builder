package com.example.backend.controllers;

import com.example.backend.entities.Website;
import com.example.backend.repositories.WebsiteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/websites")
public class WebsiteController {

    @Autowired
    private WebsiteRepository websiteRepository;

    @GetMapping
    public List<Website> getAllWebsites() {
        return websiteRepository.findAll();
    }

    @PostMapping
    public Website createWebsite(@RequestBody Website website) {
        return websiteRepository.save(website);
    }

    @PutMapping("/{websiteId}")
    public Website updateWebsiteSettings(@PathVariable String websiteId, @RequestBody Website website) {
        return websiteRepository.save(website);
    }


}
