package com.example.backend.entities;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Password {
    @Id
    @Column(name = "user_id")
    private String userId;
    private String hash;

    @OneToOne
    @MapsId
    @JoinColumn(name = "user_id")
    private User user;
}
