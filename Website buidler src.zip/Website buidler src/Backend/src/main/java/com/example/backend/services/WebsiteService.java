package com.example.backend.services;

import com.example.backend.entities.Website;
import com.example.backend.repositories.WebsiteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;


@Service
public class WebsiteService {

    @Autowired
    private WebsiteRepository websiteRepository;

    @PostMapping
    public Website createWebsite(@RequestBody Website website) {
        return websiteRepository.save(website);
    }

    @GetMapping
    public List<Website> getWebsites(@PathVariable String userId) {
        return websiteRepository.findAll();
    }

}
