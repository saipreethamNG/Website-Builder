package com.example.backend.services;

import com.example.backend.entities.Password;
import com.example.backend.entities.User;
import com.example.backend.repositories.PasswordRepository;
import com.example.backend.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private static UserRepository userRepository;

    @Autowired
    private PasswordRepository passwordRepository;

    public static Optional<User> getUserById(String id) {
        return userRepository.findById(id);
    }

    public User createUser(String name, String email, String password) {
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        String hashedPassword = bCryptPasswordEncoder.encode(password);

        User newUser = new User();
        newUser.setName(name);
        newUser.setEmail(email);

        Password newPassword = new Password();
        newPassword.setHash(hashedPassword);
        newPassword.setUser(newUser);

        newUser.setPassword(newPassword);

        return userRepository.save(newUser);
    }

}
